$(window).load(function(){
	$('.modal-backdrop').fadeOut('fast', function(){
		$('.modal-backdrop').removeClass('fade');
		$('.modal-backdrop').removeClass('in');
		$('.modal-backdrop').removeClass('modal-backdrop');
	})
});
$(document).ready(function(){
	alert(1);
});