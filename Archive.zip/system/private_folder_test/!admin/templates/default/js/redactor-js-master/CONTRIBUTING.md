# Contributing

I love pull-requests. However, this repo is just a mirror of [redactor-js official website](http://redactorjs.com/) hosted here for your, my dear GitHubbers, convenience.

Thus, no pull-requests will be accepted and there's very low chance original authors will look at the issues.

Sorry about that.
