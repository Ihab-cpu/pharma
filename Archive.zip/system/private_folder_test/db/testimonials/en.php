<?php
    $data_arr = array(
    	array(
            'Matthew',
            'USA',
            'Delivery was OK.',
        ),
        array(
            'Simona',
            'USA',
            'First time since ages I\'m happy. It\'s great! An order was delivered on time. Everything ok. Thanks again',
        ),
        array(
            'Kaiman',
            'United Kingdom',
            'Easy to place order and promptly processed.',
        ),
        array(
            'Smith S.',
            'United Kingdom',
            'Great experience with them!',
        ),
        array(
            'Dorothy',
            'Andorra',
            'Excellent service, and dealt with my query very efficiently. Good prices and great value for money.',
        ),
        array(
            'Samuel',
            'Irish France',
            'They ship very speedy and keep you informed as to the day to day progress of shipping. I\'ve used them for several years and I\'m always very pleased. Very honest, great site.',
        ),
        array(
            'Sarah',
            'Spain',
            'Thank you for your fast and courteous service, it is much appreciated. Service like this is rare these days and does not go unnoticed. Thanks to all the people who formulated the product, but also to the people that had delivered it to me so quickly.',
        ),
        array(
            'Piter N.',
            'Italy',
            'Very pleased with shipment and customer service. Will place re-order very soon.',
        ),
        array(
            'Barbara',
            'Sweden',
            'The order came sooner than expected and was as advertised or better. I am 100% satisfied.',
        ),
        array(
            'Jacob',
            'France',
            'Fast service...... very helpful customer service....couldn\'t get the website to process my order so I phoned and got great help and speedy delivery with regular shipping on the order….',
        ),
        array(
            'Alex',
            'France',
            'I like this company, they keep you updated, send things fast and have a great selection.',
        ),
        array(
            'Mark',
            'Deutschland',
            'i ordered two times from france, 10 days for delivery, no problem with customs, and good quality products',
        ),
        array(
            'Andy',
            'Ireland',
            'Quick and fast for me.',
        ),
        array(
            'Erica',
            'Germany',
            'As the people said, it really like the one as we want!!! Cheap and good.',
        ),
        array(
            'Sophia',
            'France',
            'This is my first review of an online pharmacy. I\'ve relied on other people\'s reviews when trying out an online pharmacy and I really appreciate them, so I decided it\'s time to let others know what my experience with a particular online pharmacy was like. This one is the best I\'ve ever dealt with. Their site is very easy to use and they carry some of the most popular medications that people are looking for. The prices are pretty good compared to other online pharmacy sites. Due to problems with high blood pressure and being on medication, was advised to try one product by doctor. I personally would not buy this drug from local chemist due to being very expensive per pill. I could afford it here at HELPFUL online Pharmacy. This is now my exclusive online pharmacy.',
        ),
        array(
            'Leeroy',
            'Italy',
            'I have ordered three times. I always got my order. For the most part I didn\'t have to wait too long. The content of the package was fine. I saved some money, got the drug I know and didn\'t have to wait too long for it to arrive. I\'m pretty pleased',
        ),
        array(
            'Charles',
            'Deutschland',
            'Much savings to be had shopping here instead of going to a local drug store. They also have free gifts when you order!',
        ),
        array(
            'Jessica',
            'Austria',
            'They had good prices for the pills I wanted.',
        ),
        
        array(
            'David',
            'Germany',
            'I received the order and it was on time and the pills work great. My wife thanks you, I thank you, the bed thanks you, the room , sheet, etc…….',
        ),
        array(
        	'Michael',
        	'Deutschland',
        	'The prices are low. I navigated several pharmacies and can say that this pharmacy is great. buy only here. best price and great quality. I made four orders and received on time with no any delay.'
        ),
    );
?>