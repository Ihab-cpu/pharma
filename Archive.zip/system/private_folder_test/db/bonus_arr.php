<?php
	
	function get_bonus_data_arr() {
		$bonus_arr = array(
	        'Viagra' => array(
        		'2',  // cnt
        		'100',
        		'mg',
        		'pills',
        		'Viagra'
	        ),
	        'Cialis' => array(
        		'2', // cnt
        		'20',
        		'mg',
        		'pills',
        		'Cialis'
	        ),
	        'Levitra' => array(
        		'2', // cnt
        		'20',
        		'mg',
        		'pills',
        		'Levitra'
	        ),
	    );
	    return $bonus_arr;
	}
	
?>