<p>
	We are always ready to assist you. We value every customer and we know what long-term relations are. 
<br>
	If you happen to have any question please contact our customer care specialists. You will receive a response for sure.
<br>
	Please use the form below to receive a quick reply. Our customer care department speak English.
</p>