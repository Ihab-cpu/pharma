<h1>We are glad to meet you in our Online Worldwide Drug Store!</h1>
<p>
	The pharmacy you are currently dealing with comes first in the market of delivering and distribution  of high-quality medications throughout the world. The primary target of our company is to supply professionally manufactured brand and generic medications at the lowest prices you would never have come across in your local medical stores.   We ship all over the world and warrant top-quality service. You save your money and time with us.
</p>
<p>
	In order to provide a highly proficient service, we concentrate attention on the quality of our medications. For this purpose, we cooperate with the most dependable manufacturers and select the licensed pharmacists medicines only.
</p>
<p>
	Our customers state of health and speedy delivery are our priority mission. Therefore we keep to the strictest security and privacy standards  to save your personal information and the one of e-commerce.  We do our best in terms of professional and fast service, for you to be satisfied and visit to our company again.
</p>
<p>
	To order a product online, you just have to place your order on our site. If you prefer convenience of making purchases, this way of ordering is right for you! The delivery will be organized as promptly as practicable. We do not require any signups and are ready for contacts any minute!
	<br>
	Sincerely,
	<br>
	Customer Care  Team
</p>
<p>
	Thank you!
</p>