<?php
	function cover_good_str($str) {
		$befor = '<span style="color:green;">';
		$after = '</span>';
		$str = $befor . $str . $after;
		return $str;
	}
?>