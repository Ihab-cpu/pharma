<?php

	index($global_arr);

	function index($global_arr) {
		
		$a = 1;
		$b = 2;
		$c = 3;
		$g = $a * $b * $c;
		$ax = "some text for us";
		echo 'Hello! I am auth.php controller.';
	}
?>