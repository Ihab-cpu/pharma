<?php
// ─── CONFIG ────────────────────────────────────────────────────────────────
const PHARM_URL     = 'https://pharmempire.com/index.php';
const USERNAME      = 'txt';
const PASSWORD      = '123qwe';
const BRIDGE_URL    = 'https://healuslab.com/fb-capi.php';
const POSTBACK_URL  = 'https://adv-rl.com/trk/postback?subid=%s&status=%s';
const PROCESSED_IDS = __DIR__ . '/processed.json';
const LOG_FILE      = __DIR__ . '/logs/sync.log';
const API_KEY       = 'N1TUFwNT0U2jgt9ZH1xEtZPtEnVWFjds';

// ─── START LOG ─────────────────────────────────────────────────────────────
date_default_timezone_set('UTC');
@mkdir(__DIR__ . '/logs');
file_put_contents(LOG_FILE, date('c') . " === pharmbot.php START ===\n", FILE_APPEND);

// ─── INIT CURL SESSION ─────────────────────────────────────────────────────
$cookieFile = tempnam(sys_get_temp_dir(), 'ph');
$ch = curl_init();
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_COOKIEJAR      => $cookieFile,
  CURLOPT_COOKIEFILE     => $cookieFile,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_TIMEOUT        => 15,
]);

// ─── LOGIN FIRST ───────────────────────────────────────────────────────────
curl_setopt_array($ch, [
  CURLOPT_URL  => PHARM_URL,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => http_build_query([
    'page'      => 'authorize',
    'pagetogo'  => 'sales',
    'username'  => USERNAME,
    'password'  => PASSWORD
  ])
]);
curl_exec($ch);

// ─── FETCH API JSON ────────────────────────────────────────────────────────
$today = date('Y-m-d');
$apiUrl = PHARM_URL . '?service=api'
        . '&api_key=' . API_KEY
        . '&date_from=' . $today
        . '&date_to=' . $today
        . '&format=json';

curl_setopt_array($ch, [
  CURLOPT_URL  => $apiUrl,
  CURLOPT_POST => false
]);
$json = curl_exec($ch);
file_put_contents(__DIR__ . '/logs/raw-response.json', $json);
$data = json_decode($json, true);
if (!isset($data['orders']) || !is_array($data['orders'])) {
  file_put_contents(LOG_FILE, date('c') . " ❌ JSON decode error or missing 'orders'\n", FILE_APPEND);
  exit;
}

// ─── LOAD PROCESSED LIST ───────────────────────────────────────────────────
$seen = @json_decode(@file_get_contents(PROCESSED_IDS), true) ?: [];

// ─── PROCESS EACH ORDER ────────────────────────────────────────────────────
$count = 0;
foreach ($data['orders'] as $o) {
  $orderId = $o['order_id'] ?? '';
  $subid   = $o['sub_id']   ?? '';
  $status  = strtolower($o['status'] ?? '');
  $amount  = floatval(str_replace(['$', ','], '', $o['comission'] ?? 0));

  if (!$orderId || !$subid || in_array($orderId, $seen)) continue;

  // Map status
  $map = [
    'approved' => 'sale',
    'waiting'  => 'upsale',
    'declined' => 'rejected',
  ];
  if (!isset($map[$status])) continue;
  $ktrStatus = $map[$status];

  // Fire Facebook CAPI
  $payload = [
    'evName' => 'Purchase',
    'eid'    => "Purchase_$orderId",
    'kp'     => $subid,
    'extra'  => [
      'currency' => 'USD',
      'value'    => $amount
    ]
  ];
  $fb = curl_init(BRIDGE_URL);
  curl_setopt_array($fb, [
    CURLOPT_POST           => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS     => json_encode($payload),
    CURLOPT_TIMEOUT        => 8,
  ]);
  curl_exec($fb);
  curl_close($fb);

  // Fire Keitaro postback
  $url = sprintf(POSTBACK_URL, urlencode($subid), $ktrStatus);
  file_get_contents($url);

  $seen[] = $orderId;
  file_put_contents(LOG_FILE, date('c') . " ✔ Sent $orderId [$subid] → $ktrStatus ($amount)\n", FILE_APPEND);
  $count++;
}

// ─── SAVE PROCESSED LIST ───────────────────────────────────────────────────
file_put_contents(PROCESSED_IDS, json_encode(array_values($seen), JSON_PRETTY_PRINT));
file_put_contents(LOG_FILE, date('c') . " ✅ Done. $count new sent.\n", FILE_APPEND);
?>
